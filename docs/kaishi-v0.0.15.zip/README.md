<!-- markdownlint-disable MD033 MD041 -->

<img
  align="right"
  alt="Logo of the Kaishi Starter Template"
  height="261"
  src="https://kura.pro/kaishi/images/logos/kaishi.svg"
  width="261"
  />

<!-- markdownlint-enable MD033 MD041 -->

## Kaishi.one 🌏

Source code of [Kaishi.one](https://kaishi.one), the official website of [**Kaishi**](https://github.com/sebastienrousseau/kaishi.one.github.io), a Shokunin Static Site Generator starter template.

*Part of the [Mini Functions][0] family of libraries.*

<!-- markdownlint-disable MD033 MD041 -->
<center>
<!-- markdownlint-enable MD033 MD041 -->

![Banner of the Kaishi Starter Template][banner]

<!-- markdownlint-disable MD033 MD041 -->
</center>
<!-- markdownlint-enable MD033 MD041 -->

[banner]: https://kura.pro/kaishi/images/titles/title-kaishi.svg "Banner of the Kaishi Starter Template"
[0]: https://minifunctions.com/ "Mini Functions"